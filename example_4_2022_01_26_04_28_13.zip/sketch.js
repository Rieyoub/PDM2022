function setup() {
  createCanvas(400, 400);
}

function draw() {
  background('blue');
  fill('green')
  stroke('white');
  strokeWeight(7);
  circle(200,200,300);
  fill('red');
  beginShape();
  vertex(50,150);
  vertex(160,150);
  vertex(200,50);
  vertex(240,150);
  vertex(350,150);
  vertex(260,220);
  vertex(300,320);
  vertex(200,270);
  vertex(100,320);
  vertex(140,220);

  
  endShape(CLOSE);
}