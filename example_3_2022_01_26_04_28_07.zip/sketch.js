function setup() {
  createCanvas(200, 100);
}

function draw() {
  background(0);
  fill('yellow');
  arc(50, 50, 80, 80, PI+QUARTER_PI, PI-QUARTER_PI);
  fill('red');
  rect(110, 40, 70, 50);
  noStroke();
  circle(145,45,70);
  fill('white');
  circle(162,48,25);
  circle(128,48,25);
  fill('blue');
  circle(162,48,16);
  circle(128,48,16);
}