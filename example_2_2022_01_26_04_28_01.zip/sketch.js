function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(250);
  circle(185,200,100);
  fill(255,0,0,100);
  noStroke();
  circle(150,150,100);
  fill(0,0,255,100);
  circle(115,200,100);
  fill(0,255,0,100);
  
}

