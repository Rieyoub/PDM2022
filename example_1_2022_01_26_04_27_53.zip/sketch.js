function setup() {
  createCanvas(300, 150);
}

function draw() {
  
  background('#0f0');
  circle(75, 75, 100);
  rect(170, 25, 100, 100);
}